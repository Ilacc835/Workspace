//Isaac Laccone 1/16/2024 Creating class which displays song lyrics
public class SongLyrics {

	public static void main(String[] args) {
		System.out.println("Back in black");
		System.out.println("I hit the sack");
		System.out.println("I've been too long, I'm glad to be back");

	}

}
