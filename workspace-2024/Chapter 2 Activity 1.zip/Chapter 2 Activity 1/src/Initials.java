// Isaac Laccone 1/23/2024 Write a program that declares variables to hold your initials. Display the three initials with a period following each one
public class Initials {

	public static void main(String[] args) {
		var init1 = "J";
		var init2 = "M";
		var init3 = "F"; 
		
		System.out.println(init1 + "." + init2 + "." + init3 + ".");
	}

}
