// Isaac Laccone 1/16/2024 Write a class that displays your favorite movie quote, the movie it comes from, the character who said it, and the year of the movie
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("I'll be back");
		System.out.println("The Terminator");
		System.out.println("Terminator");
		System.out.println("1984");

	}

}
